<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OrderLog extends Model
{
    /** @use HasFactory<\Database\Factories\OrderLogFactory> */
    use HasFactory;
    protected $table = 'order_log';

    protected $fillable = ['order_item_id', 'stock_movement_id'];

    public function orderItem(): BelongsTo
    {
        return $this->belongsTo(OrderItem::class);
    }

    public function stockMovement(): BelongsTo
    {
        return $this->belongsTo(StockMovement::class);
    }
}
