<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SizeCategory extends Model
{
    /** @use HasFactory<\Database\Factories\SizeCategoryFactory> */
    use HasFactory;
    protected $fillable = ['category_name'];

    public function productVariants(): HasMany
    {
        return $this->hasMany(ProductVariant::class, 'category_id');
    }
}

