<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class StockMovement extends Model
{
    /** @use HasFactory<\Database\Factories\StockMovementFactory> */
    use HasFactory;
    protected $fillable = ['product_id', 'movement_id', 'quantity_change'];

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function movementType(): BelongsTo
    {
        return $this->belongsTo(MovementType::class, 'movement_id');
    }

    public function stockLogs(): HasMany
    {
        return $this->hasMany(StockLog::class);
    }

    public function orderLogs(): HasMany
    {
        return $this->hasMany(OrderLog::class);
    }
}
